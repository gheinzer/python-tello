from lib.tello import tello
import time
import threading
from wireless import Wireless
drone = tello()
drone.MPR()
